package paquete01;
    import java.util.Scanner;
    import paquete02.Cuidad;
    import paquete02.Doctor;
    import paquete02.Enfermero;
    import paquete02.Hospital;
public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String nombreHops;
        String nombreDoctor;
        String nombreEnfermero;
        String nombreCuidad; 
        String direcionHops;
        Cuidad provinciahops;
        double sueldo;
        double sueldo2;
        String tipo;
        String tipo2;
        Doctor [] doctores;
        int numespecilistas;
        int numEnfermeros;
        
             
        System.out.println("Ingrese el nombre del Hospital: ");
        nombreHops = sc.nextLine();
        System.out.println("Ingrese la direccion del Hospital: ");
        direcionHops = sc.nextLine();
        System.out.println("Ingrese la cuidad del Hospital: ");
        nombreCuidad = sc.nextLine();
        System.out.println("Ingrese el numero de especialitas: ");
        numespecilistas = sc.nextInt();
        
        doctores = new Doctor(numespecilistas); 
        
        for (int i = 0; i < numespecilistas; i++){
            System.out.printf("Ingrese el nombre del doctor: %s\n", i + 1);
            nombreDoctor = sc.nextLine();
            System.out.printf("Ingrese el sueldo del doctor: %.2f\n", i + 1);
            sueldo = sc.nextDouble();
            System.out.printf("Ingrese la especialisacion del doctor: %s\n",i+1);
            tipo = sc.nextLine();
        }
        System.out.println("Ingrese el numero de enfermeros: ");
        numEnfermeros = sc.nextInt();
        for (int i = 0; i < numEnfermeros; i++){
            System.out.println("Ingrese el nombre del Enfermer@: ");
            nombreEnfermero = sc.nextLine();
            System.out.println("Ingrese el sueldo del Enfermer@: ");
            sueldo2 = sc.nextDouble();
            System.out.println("Ingrese el tipo de contrato del Enfermer@: ");
            tipo2 = sc.nextLine();
        }
        
        
        
    }
}
