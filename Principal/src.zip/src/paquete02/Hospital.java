package paquete02;
public class Hospital {
    
    private String direccion;
    private String nombre;  
    private Cuidad ciudad;  
    private int especialidades;
    private Doctor [] doctores;
    private Enfermero[] enfermeros;

    public Hospital(String direccion, String nombre, Cuidad ciudad, int especialidades,
            Doctor[] doctores, Enfermero[] efermeros) {
        this.direccion = direccion;
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.especialidades = especialidades;
        this.doctores = doctores;
        this.enfermeros = efermeros;
    }
   
    public void establecerDireccion(String n){
        direccion = n;
    }
    public void establecerNombre (String n){
        nombre = n;
    }
    public String obtenerDireccion(){
        return direccion;
    }
    public String obtenerNombre(){
        return nombre;
    }
    public Doctor[] obtenerDoctores(){
        return doctores;
    }
    public Enfermero[] obtenerEnfermero(){
        return enfermeros;
    }
    public double totalsueldo(){
        double salariototal=0;
        for (int i = 0; i <  obtenerDoctores().length; i++ ){
           salariototal += obtenerDoctores()[i].obtenerSueldo();   
        }
        for (int i = 0; i <  obtenerEnfermero().length; i++ ){
           salariototal += obtenerEnfermero()[i].obtenerSueldo();   
        }
         return salariototal;
    }
    
    @Override
    public String toString(){
        String cadena = obtenerNombre().toUpperCase()+" \n";
        cadena = String.format("Dirrecion: %s\n Ciudad: %s\n Provincicia%s\n"
                + "Numero de especialistas: %d\n Lista de medicos: \n");
                for (int i = 0; i <  obtenerDoctores().length; i++ ){
                    cadena = String.format("- %s\t\t - Sueldo: %s - %s\n", cadena,
                            obtenerDoctores()[i].obtenerNombre(),
                            obtenerDoctores()[i].obtenerSueldo(),
                            obtenerDoctores()[i].obtenerTipo());
                }
                cadena = "Lista de enfermeros"; 
                for (int i = 0; i <  obtenerEnfermero().length; i++ ){
                    cadena = String.format("- %s\t\t - Sueldo: %s - %s\n", cadena,
                            obtenerEnfermero()[i].obtenerNombre(),
                            obtenerEnfermero()[i].obtenerSueldo(),
                            obtenerEnfermero()[i].obtenerTipo());
                }
                cadena = "Total de sueldos a pagar por mes: " + totalsueldo();
        return cadena;
    }
}
